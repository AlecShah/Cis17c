//////////////////////////////////////////////////////////////////////////
/*
 * Connect 4 Project
 * Alec Shahverdian
 * CIS 17c
 * Professor Mark Lehr
 */
//////////////////////////////////////////////////////////////////////////

#include <iostream>
#include <iomanip>
#include <list>
#include <string>
#include <map>
#include <queue>
#include <stack>
#include <algorithm>
#include <vector>

using namespace std;

///////////////////////////////////////////
/*
Struct for defining Player name and ID on board
*/
///////////////////////////////////////////
struct playerInfo
{
        //players name (max 30 char
	char playerName[30];
        
        //player ID (X and O)
	char playerID;
};

///////////////////////////////////////////
/*
 * Struct for planned list funtion in game
 */
///////////////////////////////////////////
struct Link
{
    int data;        
    Link *linkPtr;  
};

/////////////////////////////////////////////////////////////
/*
Declaring functions for board and player interactions 
*/
/////////////////////////////////////////////////////////////

//Declare Player dropping piece function
int PlayerDrop(char board[][10], playerInfo activePlayer);

//declare check for pieces below function
void CheckBellow (char board[][10], playerInfo activePlayer, int dropChoice);

//declare display board function
void DisplayBoard (char board[][10] );

//declare check for for connected pieces function
int CheckFour (char board[][10], playerInfo activePlayer);

//declare full board check function
int FullBoard(char board[][10]);

//declare win output function
int PlayerWin (playerInfo activePlayer);

//declare restart function
int restart (char board[][10]);

//declare display rules output function
void DsplyRules(int dropChoice);

//int for game count
int a = 1;

//moves taken list
list<int> list1;

//declare function for tracking moves taken
int movelist(int dropChoice, list<int> list1);

//queue which holds players drop choices
queue<int> moves;

//Prototypes for unused link implementation 
Link *fillLst(int);         
void  prntLst(Link *);      
void  destLst(Link *);     
Link * endLst(Link *);     
void   addLst(Link *,int);  
int   findLst(Link *,int);  
Link * fndLst(Link *,int);  
int    cntLst(Link *);    

//stack which holds players drop choices
//stack<int> moves

//function for redoing last move and removing it from list history
//int removeMove(int dropcChoice)

//for determining moves mad this match
//int movesCount(queue<int> moves)

//(WIP) bot commands
//int botcom ();

///////////////////////////////////////////
/*
Main Function: Introduces games and rules, 
then runs the main game play loop 
*/
///////////////////////////////////////////

int main()
{       //Pointers for player 1 and 2 and their ID using player info
	playerInfo playerOne, playerTwo; 
	
        //Board image dimensions
        char board[9][10];
        
        //Board piece placement dimensions
	int Width = 7; 
	int Height = 6; 
       
        //Pointers for values used in later functions
	int dropChoice, win, full, again;
       
        //Value for determining if player would like to play against a bot
        int posbot;
        
        //map for player 1 and 2 usernames
        map<char,char> first;

        //Display Title Art for game
        cout << setw(5);
        
        cout <<
          "██╗      ██╗███████╗██╗         ██████╗  ██████╗  ███╗     ███╗ ███████╗"<< endl    
        <<"██║      ██║██╔════╝██║        ██╔════ ██╔═══██╗ ████╗   ███║ ██╔════╝"<< endl
        <<"██║ █╗  ██║█████╗   ██║        ██║       ██║     ██║ ██╔████╔██║ █████╗  " << endl      
        <<"██║███╗██║██╔══╝   ██║        ██║       ██║     ██║ ██║╚██╔╝██║ ██╔══╝  "  << endl     
        <<"╚███╔███╔╝███████╗███████╗╚██████╗╚██████╔╝██║ ╚═╝  ██║ ███████╗" << endl    
        <<" ╚══╝╚══╝ ╚══════╝ ╚══════╝ ╚═════╝ ╚═════╝   ╚═╝        ╚═╝ ╚══════╝" << endl << endl     
         
        <<"████████╗   ██████╗ "  << endl
        <<"╚══██╔══╝██╔═══  ██╗"  << endl      
        <<"     ██║     ██║       ██║"  << endl     
        <<"     ██║     ██║       ██║" << endl
        <<"     ██║      ╚██████╔╝" << endl  
        <<"     ╚═╝       ╚═════╝ "   << endl << endl 
                
        <<" ██████╗ ██████╗   ███╗    ██╗███╗    ██╗███████╗  ██████╗████████╗"  << endl      
        <<"██╔════╝██╔═ ██╗  ████╗   ██║████╗   █║ ██╔════╝██╔════╝╚══██╔══╝" << endl
        <<"██║        ██║   ██║  ██╔██╗ ██║██╔██╗  █║ █████╗   ██║             ██║   "  << endl      
        <<"██║        ██║   ██║  ██║╚██╗██║██║╚██╗█║ ██╔══╝   ██║             ██║   "   << endl     
        <<"╚██████╗╚█████╔╝  ██║ ╚████║██║╚████║ ███████╗╚██████╗     ██║   " << endl
        <<" ╚═════╝ ╚═════╝   ╚═╝  ╚═══╝╚═╝  ╚═══╝  ╚══════╝ ╚═════╝     ╚═╝   "   << endl << endl     
          
        <<"███████╗ ██████╗ ██╗     ██╗ ██████╗ "<< endl
        <<"██╔════╝██╔══██╗██║     ██║ ██╔══██╗"  << endl     
        <<"█████╗   ██║    ██║██║     ██║ ██████╔╝"  << endl      
        <<"██╔══╝   ██║    ██║██║     ██║ ██╔══██╗" << endl       
        <<"██║        ╚█████╔╝╚██████╔╝  ██║   ██║" << endl
        <<"╚═╝         ╚════╝    ╚═════╝   ╚═╝   ╚═╝"  << endl << endl;      
                
        //Introduction text for players, showing rules and instructions 
        cout << setw(5);
        
	cout <<
        "-------------------------------------------------------------------------"
        "\nRules:\n"
        "-------------------------------------------------------------------------\n"
        "+Note: 1-2 Players required\n"
        "+Player 1 goes first, placing piece in grids 1-7, followed by player 2\n"
        "+Player 1 will be represented by X\n"
        "+Player 2 will be represented by O\n"
                
        "-------------------------------------------------------------------------"
        "\nWin conditions:\n"        
        "-------------------------------------------------------------------------\n"
        "Game is won when...\n"
        "Four pieces in a row are connected\n"
        "Four Pieces in a column are connected\n"
        "Four pieces in a diagonal are connected\n"
                
        "-------------------------------------------------------------------------"
        "\nBot Commands (WIP):\n"
        "-------------------------------------------------------------------------\n"
        "Note: If you are playing solo, set your player 2's function 2 bot when prompted\n"
        "If you wish to play against a bot, please follow the rules explained afterwards.\n"<<endl << endl;
        
        //Setting name for first player
        cout << setw(5);
	cout << "Player One please enter your name: ";
        cin  >> playerOne.playerName;
	
        //Player One's Token ID
        playerOne.playerID = 'X';
	
        //Setting name for second player
        cout << setw(5);
        cout << "Player Two please enter your name: ";
	cin  >> playerTwo.playerName;
	
        //Player Two Token ID
        playerTwo.playerID = 'O';
        
        //Map for player 1 and 2 usernames
        /*first['a'] = playerOne.playerName;
        first['b'] = playerTwo.playerName;
        
        map<char, char>::iterator it;
            
        for(it=first.begin(); it!=first.end(); ++it)
            {
            cout << it->first << " ==> " << it->second << '\n';
            }*/
        
        //For solo play
        cout << setw(5);
        cout << "Is Player 2 a bot?:\n"
              "Enter 1 for Yes, 2 for NO\n";
        
        cin >> posbot;
        
        //For loop for bot instructions
        if(posbot = 1)
        {
            cout << "Bot instructions:\n" 
                    "for playing against bot instructions are simple\n"
                    "when bots turn is prompted, enter in the number 8 for the bots move.\n";
        }
        else
        {
            cout << "Good luck!\n" << playerOne.playerName << " and 2! " << playerTwo.playerName <<endl << endl;
        }
        
        //setting values for declared variables
	full = 0;
        win = 0;
	again = 0;
	
        //For Displaying board 
        DisplayBoard(board);
	
        do
	{
            //Main game play loop
		dropChoice = PlayerDrop(board, playerOne);
		CheckBellow(board, playerOne, dropChoice);
		DisplayBoard(board);
                DsplyRules;
		win = CheckFour(board, playerOne);
		if (win == 1)
		{
			PlayerWin(playerOne);
			again = restart(board);
			if (again == 2)
			{
				break;
			}
		}

		dropChoice = PlayerDrop(board, playerTwo);
		CheckBellow(board, playerTwo, dropChoice);
		DisplayBoard(board);
		win = CheckFour(board, playerTwo);
		if (win == 1)
		{
			PlayerWin(playerTwo);
			again = restart(board);
			if (again == 2)
			{
				break;
			}
		}
                
                //Output for if a board is filled (Draw)
		full = FullBoard(board);
		if (full == 7)
		{
			cout << "The board has been completely filled\n" 
                        << "The match has ended in a draw, please restart." << endl;
			again = restart(board);
		}

	}while (again != 2);
	
return 0;
}

///////////////////////////////////////////
/*
Function that allows player to restart the 
game after a match is won
*/
///////////////////////////////////////////
int restart (char board[][10])
{
	int restart;

	cout << "Would you like to restart? Yes(1) No(2): ";
	
        cin  >> restart;
	
        if (restart == 1)
	{
	for(int i = 1; i <= 6; i++)
	{
	for(int j = 1; j <= 7; j++)
            {
		board[i][j] = '.';
            }
	}
	}
	else
	cout << "Thanks For Playing!" << endl;
return restart;
}

///////////////////////////////////////////
/*
Function for taking player drop choice
and dropping a piece in that column
*/
///////////////////////////////////////////
int PlayerDrop(char board[][10], playerInfo activePlayer)
{
	int dropChoice;
	
        queue<int> moves;
        
        //struct<int> moves;
        
        do
	{
		cout << activePlayer.playerName << "'s Turn ";
		cout << "Please enter a number between 1 and 7: ";
		
                cin  >> dropChoice;
                
                moves.push(dropChoice);
                
                //moves.push(dropChoice);
                
		while (board[1][dropChoice] == 'X' || board[1][dropChoice] == 'O')
		{
			cout << "FULL ROW! Please enter a new row: ";
			cin  >> dropChoice;
		}

	}while (dropChoice < 1 || dropChoice > 7);
        
        
        
return dropChoice;
}

///////////////////////////////////////////
/*
Tracks all moves used during the game
*/
///////////////////////////////////////////
int movelist(int dropChoice, list<int> list1)
{
    list1.push_back(dropChoice);
}

///////////////////////////////////////////
/*
Allows player to display list of basic 
rules again during game play
*/
///////////////////////////////////////////
void DsplyRules(int dropChoice)
{
        if(dropChoice = 0)
        {
           cout <<
        "-------------------------------------------------------------------------"
        "\nRules:\n"
        "-------------------------------------------------------------------------\n"
        "+Note: 1-2 Players required\n"
        "+Player 1 goes first, placing piece in grids 1-7, followed by player 2\n"
        "+Player 1 will be represented by X\n"
        "+Player 2 will be represented by O\n"
                
        "-------------------------------------------------------------------------"
        "\nWin conditions:\n"        
        "-------------------------------------------------------------------------\n"
        "Game is won when...\n"
        "Four pieces in a row are connected\n"
        "Four Pieces in a column are connected\n"
        "Four pieces in a diagonal are connected\n"
                
        "-------------------------------------------------------------------------"
        "\nBot Commands (WIP):\n"
        "-------------------------------------------------------------------------\n"
        "Note: If you are playing solo, set your player 2's function 2 bot when prompted\n"
        "If you wish to play against a bot, please follow the rules explained afterwards.\n"<<endl << endl;
        }
}

///////////////////////////////////////////
/*
Function that displays the board used in
each turn during the game
*/
///////////////////////////////////////////
void DisplayBoard (char board[][10])
{
	int rows = 6, columns = 7, i, j;
	
	for(i = 1; i <= rows; i++)
	{
		cout << "|";
		for(j = 1; j <= columns; j++)
		{
			if(board[i][j] != 'X' && board[i][j] != 'O')
				board[i][j] = '.';

			cout << board[i][j];
			
		}

		cout << "|" << endl;
	}

}

///////////////////////////////////////////
/*
Function that checks if the board is full
*/
///////////////////////////////////////////
int FullBoard( char board[][10] )
{
	int full;
	full = 0;
        
	for ( int i = 1; i <= 7; ++i )
	{
		if ( board[1][i] != '.' )
			++full;
	}

return full;
}

///////////////////////////////////////////
/*
Function that checks for pieces below where
a player would place a new piece in a column
*/
///////////////////////////////////////////
void CheckBellow ( char board[][10], playerInfo activePlayer, int dropChoice )
{
	int length, turn;
	length = 6;
	turn = 0;

	do 
	{
		if (board[length][dropChoice] != 'X' && board[length][dropChoice] != 'O')
		{
			board[length][dropChoice] = activePlayer.playerID;
			turn = 1;
		}
		else
		--length;
	}while ( turn != 1);


}

///////////////////////////////////////////
/*
Function that checks if four pieces are
connected on the board
*/
///////////////////////////////////////////
int CheckFour (char board[][10], playerInfo activePlayer)
{
//char for X and O pieces
char XO;

//int for win condition
int win;
	
XO = activePlayer.playerID;

win = 0;
        
        //function checks for columns 1-7
	for( int i = 8; i >= 1; --i )
	{
		
	for( int j = 9; j >= 1; --j )
	{
			
               if(board[i][j] == XO     
                        &&
		
               board[i-1][j-1] == XO 
                        &&
		
               board[i-2][j-2] == XO 
                        &&
		
                board[i-3][j-3] == XO)
		{
                    win = 1;
		}
			

		if(board[i][j] == XO   
                        &&
		
                board[i][j-1] == XO 
                        &&
		
                board[i][j-2] == XO 
                        &&
		
                board[i][j-3] == XO)
		{
                    win = 1;
		}
					
		if(board[i][j] == XO   
                        &&
		
                board[i-1][j] == XO 
                        &&
		
                board[i-2][j] == XO 
                        &&
                
                board[i-3][j] == XO)
		{	
                    win = 1;
		}
					
		if(board[i][j] == XO     
                        &&
		
                board[i-1][j+1] == XO 
                        &&
		
                board[i-2][j+2] == XO 
                        &&
		
                board[i-3][j+3] == XO)
		{
                    win = 1;
		}
						
		if (board[i][j] == XO   
                        &&
		
                board[i][j+1] == XO 
                        &&
		
                board[i][j+2] == XO 
                        &&
		
                board[i][j+3] == XO)
		{
                    win = 1;
		}
	}
		
}

return win;
}

///////////////////////////////////////////
/*
Function that displays win message
for when a player is determined the winner
*/
///////////////////////////////////////////
int PlayerWin (playerInfo activePlayer )
{
	cout << endl << activePlayer.playerName << " Connected Four, You Win!" << endl;
        cout << "This marks the end of game " << a << endl << endl;
        
        cout << "Here are the list of moves played during that game...\n";
        
        //prints list of moves
        for (list<int>::iterator i=list1.begin(); i!=list1.end(); i++)
        cout << *i << " ";
        
        int a = a + 1;
        
        return a;
}

///////////////////////////////////////////
/*
(WIP) Bot commands for if player wants to 
play against a bot (solo play)
*/
///////////////////////////////////////////
/*
 * int botcom()
 * {
 * 
 * }
 */

///////////////////////////////////////////
/*
 Fuction to display move list queue when 
 the player so chooses
 */
///////////////////////////////////////////
/*
 * {
 * 
 * }
 * 
 */

///////////////////////////////////////////
/*
 Function to remove redo last move and remove 
 * it from list history/queue
 */
///////////////////////////////////////////
/*
 * int removeMove(int dropcChoice, queue<int> moves)
 * {
 *     //remove last drop choice from queue
 *      remove (moves, dropchoice)
 * }
 * 
 */

///////////////////////////////////////////
/*
 *Function that allows the player to inquire
 *how many moves where made so far in the match
 */
///////////////////////////////////////////
/*
 *int movesCount(queue<int> moves)
 * {
 *      int moveChoice;
 *      
 *      if(dropchoice = 15)
 *      {
 *      cout << "Would you like to see how many moves where made this match?\n";
 *      cout << "Enter 1 for yes, 2 for no" <<end << endl;
 *      
 *      cin >> moveChoice;
 *      
 *      if(moveChoice = 1)
 *      {
 *         cout << "Number of times moves is: "
            << count(moves); 
 *      }
 *      }
 * }
 * 
 */

///////////////////////////////////////////
/*
 *Planned for List link function which could
 * not be realistically implemented for final 
 * functioning version of the game
 */
///////////////////////////////////////////
Link *fillLst(int n)
{
    Link *front=new Link;
    front->data=n;     
    front->linkPtr=NULL;
    Link *next=front;    

    n--;
    do{
       Link *temp=new Link; 
       temp->data=n;        
       temp->linkPtr=NULL;  
       next->linkPtr=temp;  
       next=temp;          
    }while(--n>0);          
    
    return front;           
}

Link  *endLst(Link *front){
    Link *temp=front,*next; 
    do{
        next=temp;         
        temp=temp->linkPtr; 
    }while(temp!=NULL);     
    return next;
}

void  prntLst(Link *front){
    Link *next=front;           
    cout<<endl<<"The Beginning of the List"<<endl;
    do{
        cout<<next->data<<endl; 
        next=next->linkPtr;    
    }while(next!=NULL);         
    cout<<"The End of the List"<<endl<<endl;
}

void  destLst(Link *front){
    do{
       Link *temp=front->linkPtr;   
       delete front;              
       front=temp;                
    }while(front!=NULL);
}

int   findLst(Link *front,int value){
    int n=0;               
    Link *temp=front;       
    do{
        n++;               
        if(temp->data==value)return n;
        temp=temp->linkPtr; 
    }while(temp!=NULL);     
    return -1;               
}

void   addLst(Link *front,int data){
    Link *last=endLst(front);  
    Link *add=new Link;        
    add->data=data;           
    add->linkPtr=NULL;         
    last->linkPtr=add;      
}

Link  *fndLst(Link *front,int value){
    Link *temp=front;       
    do{
        if(temp->data==value)return temp;  
        temp=temp->linkPtr;               
    }while(temp!=NULL);                   
    return NULL;                           
}

int   cntLst(Link *front){
    int n=0;            
    Link *temp=front;   
    do{
        n++;            
        temp=temp->linkPtr;
    }while(temp!=NULL);
    return n;           
}